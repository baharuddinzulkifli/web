<?php
/* session_start();
include('config.php');

if(isset($_POST['submit']))
 {
$vehicle_name=$_POST['vehicle_name'];
$vehicle_brand=$_POST['vehicle_brand'];
$vehicle_price=$_POST['vehicle_price'];
$vehicle_fuel=$_POST['vehicle_fuel'];
$vehicle_year=$_POST['vehicle_year'];
$vehicle_capacity=$_POST['vehicle_capacity'];
$vehicle_image=$_POST['vehicle_image'];


$sql="INSERT INTO table_vehicle(vehicle_name,vehicle_brand,vehicle_price,vehicle_fuel,vehicle_year,vehicle_capacity,vehicle_image) VALUES(:vehicle_name,:vehicle_brand,:vehicle_price,:vehicle_fuel,:vehicle_year,:vehicle_capacity,:vehicle_image)";
$query = $dbh->prepare($sql);
$query->bindParam(':vehicle_name',$vehicle_name,PDO::PARAM_STR);
$query->bindParam(':vehicle_brand',$vehicle_brand,PDO::PARAM_STR);
$query->bindParam(':vehicle_price',$vehicle_price,PDO::PARAM_STR);
$query->bindParam(':vehicle_fuel',$vehicle_fuel,PDO::PARAM_STR);
$query->bindParam(':vehicle_year',$vehicle_year,PDO::PARAM_STR);
$query->bindParam(':vehicle_capacity',$vehicle_capacity,PDO::PARAM_STR);
$query->bindParam(':vehicle_image',$vehicle_image,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Vehicle posted successfully";
echo '<script language = "JavaScript">alert("Successfully add vehicle")</script>';
				print '<meta http-equiv="refresh" content="0;URL=vehicle.php">';
}
else 
{
$error="Something went wrong. Please try again";
}

} */
 include ("connect.php");
 

$vehicle_name=$_POST['vehicle_name'];
$vehicle_brand=$_POST['vehicle_brand'];
$vehicle_price=$_POST['vehicle_price'];
$vehicle_fuel=$_POST['vehicle_fuel'];
$vehicle_year=$_POST['vehicle_year'];
$vehicle_capacity=$_POST['vehicle_capacity'];
$vehicle_image=$_FILES['vehicle_image']['name'];


$sql="INSERT INTO table_vehicle(vehicle_name,vehicle_brand,vehicle_price,vehicle_fuel,vehicle_year,vehicle_capacity,vehicle_image) VALUES ('$vehicle_name', '$vehicle_brand', '$vehicle_price', '$vehicle_fuel', '$vehicle_year', '$vehicle_capacity', '$vehicle_image')" or die ("</br>Error Inserting Data.");
mysql_query($sql) or die ("Error inserting data");

echo "<center><br/><img src='Users.png' width='128' height='128' /><br/><br/><h2>Success!</h2><br/>
			<p>Prisoner data has been inserted</p><br/></center>";
			echo "<meta http-equiv=\"refresh\"content=\"2;URL=vehicle.php\">";
?> 