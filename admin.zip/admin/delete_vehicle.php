<?php
if(isset($_GET['del2']))
{
$id=$_GET['del2'];
$sql = "delete from vehicle_table  WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();
$msg="Page data updated  successfully";

}

?>