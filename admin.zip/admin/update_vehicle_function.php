<?php
if(isset($_GET['submit'])){
  include('config2.php');

 /*  $lecturerName = mysql_real_escape_string($_GET['lecturerName']);
  $lecturerID = $_GET['lecturerID'];
  $lecturerEmail = $_GET['lecturerEmail'];
  $lecturerPhone = $_GET['lecturerPhone'];
 */
 
 $vehiclename=$_GET['vehiclename'];
$vehicleproductname=$_GET['vehicleproductname'];
$vehicleprice=$_GET['vehicleprice'];
$vehiclefueltype=$_GET['vehiclefueltype'];
$vehicleyear=$_GET['vehicleyear'];
$vehiclecapacity=$_GET['vehiclecapacity'];/* 
$vehicleimage1=$_FILES["vehicleimage1"]["name"];
$vehicleimage2=$_FILES["vehicleimage2"]["name"]; */
$id=$_GET['id'];

    $sql = "UPDATE vehicle_table SET vehiclename='$vehiclename' WHERE id='$id'";
    mysql_query($sql,$con)or die(mysql_error());
    mysql_close($con);

    if($sql){
      echo '<script language = "JavaScript">alert("Successfully update account detail!")</script>';
        print '<meta http-equiv="refresh" content="0;URL=list_vehicle.php">';
    }else{
      echo '<script language = "JavaScript">alert("Unsuccessfully update account detail!")</script>';
        print '<meta http-equiv="refresh" content="0;URL=list_vehicle.php">';
    }
}
?>