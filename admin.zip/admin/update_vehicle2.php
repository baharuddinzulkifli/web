<?php 
	session_start();
	
	if (!isset($_SESSION["username"])) {
		header("Location: index.php");
	}
else{
	?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

    
<?php
include 'sidebar.php';
?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php
			   include 'header.php';
			   ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Admin</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div>

                
<h1>HELLO</h1>
                    

<div class="col-lg-12">
        <div class="box">
            <header class="dark">
                <div class="icons"><i class="fa fa-cloud-upload"></i></div>
                <h5>Update Prisoner Details</h5>
            </header>

            <div class="body">
<?php
 include ("connect.php");
 
$id = $_GET['id'];
				
$sql = "SELECT * FROM vehicle_table 
		WHERE id = '$id'";
$result = mysql_query ($sql) or die (mysql_error ());
$row = mysql_fetch_assoc($result);

?>   
				<form class="form-horizontal" method="GET" >
                
                
                    
					<div class="form-group">
                            <label for="image" class="control-label col-lg-4">Image Prisoner</label>

                            <div class="col-lg-8">
                               <img src="assets/img/prisoner/<?php echo $row ['image']; ?>"  style="width:300px;height:300px;" >
                            </div>
                        </div>
					<div class="form-group">
                            <label for="name" class="control-label col-lg-4">Name</label>

                            <div class="col-lg-8">
                                <input type="text" name="name" id="name" class="form-control" value="<?php echo $row ['vehiclename']; ?>" >
                            </div>
                        </div>
						<div class="form-group">
                            <label for="prisonerid" class="control-label col-lg-4">Prisoner id</label>

                            <div class="col-lg-8">
                                <input type="text" name="prisonerid" id="prisonerid" class="form-control" readonly="readonly" value="<?php echo $row ['prisonerid']; ?>" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="ic_number" class="control-label col-lg-4">IC Number</label>

                            <div class="col-lg-8">
                                <input type="number" name="ic_number" id="ic_number" class="form-control" value="<?php echo $row ['ic_number']; ?>" onKeyPress="if (this.value.length==12) return false" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="age" class="control-label col-lg-4">Age</label>

                            <div class="col-lg-8">
                                <input type="number" name="age" id="age" class="form-control" value="<?php echo $row ['age']; ?>" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="gender" class="control-label col-lg-4">gender</label>

                             <div class="col-lg-4">
                                <select class="form-control" name="gender" id="gender" type="text" value="<?php echo $row ['gender']; ?>" required="required">
                                    <option name = "Male" value="Male" <?php if($row['gender'] == 'Male') echo "selected"; ?>>Male</option>
					<option name = "Female" value="Female" <?php if($row['gender'] == 'Female') echo "selected"; ?>>Female</option>
                                   
                                  
                                </select>
                            </div>
                        </div>
						<div class="form-group">
                            <label for="address" class="control-label col-lg-4">Address</label >

                            <div class="col-lg-8">
                                <input type="text" name="address" id="address" class="form-control" value="<?php echo $row ['address']; ?>" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="postcode" class="control-label col-lg-4">Postcode</label>

                            <div class="col-lg-8">
                                <input type="number" name="postcode" id="postcode" class="form-control" value="<?php echo $row ['postcode']; ?>" onKeyPress="if (this.value.length==5) return false" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="state" class="control-label col-lg-4">State</label>

                           <div class="col-lg-8">
                                <select class="form-control" name="state" id="state" type="text" value="<?php echo $row ['state']; ?>" required="required">
                    <option name = "Pahang" value="Pahang" <?php if($row['state'] == 'Pahang') echo "selected"; ?>>Pahang</option>
					<option name = "Melaka" value="Melaka" <?php if($row['state'] == 'Melaka') echo "selected"; ?>>Melaka</option>
					<option name = "Selangor" value="Selangor" <?php if($row['state'] == 'Selangor') echo "selected"; ?>>Selangor</option>
					<option name = "Terengganu" value="Terengganu" <?php if($row['state'] == 'Terengganu') echo "selected"; ?>>Terengganu</option>
					<option name = "Johor" value="Johor" <?php if($row['state'] == 'Johor') echo "selected"; ?>>Johor</option>
					<option name = "Kedah" value="Kedah" <?php if($row['state'] == 'Kedah') echo "selected"; ?>>Kedah </option>
					<option name = "Kelantan" value="Kelantan" <?php if($row['state'] == 'Kelantan') echo "selected"; ?>>Kelantan </option>
					<option name = "Negeri Sembilan" value="Negeri Sembilan" <?php if($row['state'] == 'Negeri Sembilan ') echo "selected "; ?>>Negeri Sembilan </option>
					<option name = "Perak" value="Perak" <?php if($row['state'] == 'Perak') echo "selected"; ?>>Perak </option>
					<option name = "Perlis" value="Perlis" <?php if($row['state'] == 'Perlis') echo "selected"; ?>>Perlis  </option>
					<option name = "Pulau Pinang" value="Pulau Pinang" <?php if($row['state'] == 'Pulau Pinang') echo "selected"; ?>>Pulau Pinang </option>
					<option name = "Sabah" value="Sabah" <?php if($row['state'] == 'Sabah') echo "selected"; ?>>Sabah  </option>
					<option name = "Sarawak" value="Sarawak" <?php if($row['state'] == 'Sarawak') echo "selected"; ?>>Sarawak  </option>
					<option name = "Kuala Lumpur" value="Kuala Lumpur" <?php if($row['state'] == 'Kuala Lumpur ') echo "selected"; ?>>Kuala Lumpur  </option>
					<option name = "Putrajaya" value="Putrajaya" <?php if($row['state'] == 'Putrajaya') echo "selected"; ?>>Putrajaya  </option>
                                </select>
                            </div>
                        </div>
						<div class="form-group">
                            <label for="datein" class="control-label col-lg-4">date in</label>

                            <div class="col-lg-8">
                                <input type="text" name="datein" id="datein" class="form-control" value="<?php echo $row ['datein']; ?>" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="block" class="control-label col-lg-4">block</label>

                            <div class="col-lg-8">
                                <input type="text" name="block" id="block" class="form-control" value="<?php echo $row ['block']; ?>" required="required">
                            </div>
                        </div>
						<div class="form-group">
                            <label for="crimetype" class="control-label col-lg-4">Crime Type</label>

                            <div class="col-lg-8">
                                <select class="form-control" name="crimetype" id="crimetype" type="text" value="<?php echo $row ['crimetype']; ?>" required="required">
                                    <option name = "Violent Crime" value="Violent Crime" <?php if($row['crimetype'] == 'Violent Crime') echo "selected"; ?>>Violent Crime</option>
					<option name = "Property Crime" value="Property Crime" <?php if($row['crimetype'] == 'Property Crime') echo "selected"; ?>>Property Crime</option>
					<option name = "White Colar Crime" value="White Colar Crime" <?php if($row['crimetype'] == 'White Colar Crime') echo "selected"; ?>>White Colar Crime</option>
					
						 </select>
                            </div>
                        </div>
						<div class="form-group">
                               
                               <button type="submit" name="update" id="submit" class="btn btn-primary btn-block btn-flat">Update</button>
                            </div>
                    
                    <div class="alert alert-warning"><strong>Notice!</strong> Image preview only works in IE10+, FF3.6+, Chrome6.0+ and Opera11.1+. In older browsers and Safari, the filename is shown instead.</div>
                </form>
     

<h1>HELLO</h1>
	 

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

         

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
<?php
}
?>