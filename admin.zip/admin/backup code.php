<label class="col-sm-2 control-label">Vehicle Type<span style="color:red"></span></label>
<div class="col-sm-4">
<input type="text" name="vehicle_name" class="form-control" disabled value="<?php echo $row ['vehicletype_name']; ?>">
</div>
<div class="col-sm-4">
<select class="selectpicker" name="vehicle_brand" >
<option value=""> Select </option>
<?php 
 $query_select="select id,vehicletype_name from table_vehicletype";
$query= $dbh -> prepare($query_select);
//$query->bindParam(':id',$id, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
foreach($results as $result)
{ 
?>
<option value="<?php echo htmlentities($result->id);?>"><?php echo htmlentities($result->vehicletype_name);?></option>
<?php  }} ?>

</select>
</div>