<?php
        $usernm="root";
        $passwd="P@sscode";
        $host="localhost";
        $database="carrental";

        mysql_connect($host,$usernm,$passwd);

        mysql_select_db($database);
?>