<?php
session_start();
include('config.php');
if(isset($_POST['submit']))
{
$vehicletype_name=$_POST['vehicletype_name'];
$sql="INSERT INTO  table_vehicletype(vehicletype_name) VALUES(:vehicletype_name)";
$query = $dbh->prepare($sql);
$query->bindParam(':vehicletype_name',$vehicletype_name,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg=" Created successfully";
echo '<script language = "JavaScript">alert("Successfully add vehicle type")</script>';
				print '<meta http-equiv="refresh" content="0;URL=vehicletype.php">';
}
else 
{
$error="Something went wrong. Please try again";
}

}
?>