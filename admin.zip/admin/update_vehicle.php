<?php
session_start();
error_reporting(0);
include('config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_POST['submit']))
  {
$vehiclename=$_POST['vehiclename'];
$vehicleproductname=$_POST['vehicleproductname'];
$vehicleprice=$_POST['vehicleprice'];
$vehiclefueltype=$_POST['vehiclefueltype'];
$vehicleyear=$_POST['vehicleyear'];
$vehiclecapacity=$_POST['vehiclecapacity'];
$vehicleimage1=$_FILES["vehicleimage1"]["name"];
$vehicleimage2=$_FILES["vehicleimage2"]["name"]; 
$id=intval($_GET['id']); 
//$sql="INSERT INTO vehicle_table(vehiclename,vehicleproductname,vehicleprice,vehiclefueltype,vehicleyear,vehiclecapacity,vehicleimage1,vehicleimage2) VALUES(:vehiclename,:vehicleproductname,:vehicleprice,:vehiclefueltype,:vehicleyear,:vehiclecapacity,:vehicleimage1,:vehicleimage2)";

$sql="update vehicle_table set vehiclename=:vehiclename,vehicleproductname=:vehicleproductname,vehicleprice=:vehicleprice,PricePerDay=:priceperday,vehiclefueltype=:vehiclefueltype,vehicleyear=:vehicleyear,vehiclecapacity=:vehiclecapacity where id=:id ";

$query = $dbh->prepare($sql);
$query->bindParam(':vehiclename',$vehiclename,PDO::PARAM_STR);
$query->bindParam(':vehicleproductname',$vehicleproductname,PDO::PARAM_STR);
$query->bindParam(':vehicleprice',$vehicleprice,PDO::PARAM_STR);
$query->bindParam(':vehiclefueltype',$vehiclefueltype,PDO::PARAM_STR);
$query->bindParam(':vehicleyear',$vehicleyear,PDO::PARAM_STR);
$query->bindParam(':vehiclecapacity',$vehiclecapacity,PDO::PARAM_STR);

$query->bindParam(':id',$id,PDO::PARAM_STR);
$query->bindParam(':vehicleimage1',$vehicleimage1,PDO::PARAM_STR);
$query->bindParam(':vehicleimage2',$vehicleimage2,PDO::PARAM_STR); 

$msg="Data updated successfully";


  } 
 ?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

    
<?php
include 'sidebar.php';
?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php
			   include 'header.php';
			   ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Admin</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div>

                
<h1>HELLO</h1>
                    

<div class="panel panel-default">
									<div class="panel-heading"><b>Basic Info</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

<?php 
$id=intval($_GET['id']);
//$sql ="SELECT tblvehicles.*,tblbrands.BrandName,tblbrands.id as bid from tblvehicles join tblbrands on tblbrands.id=tblvehicles.VehiclesBrand where tblvehicles.id=:id";
$sql = "select vehicle_table.*, product_vehicle_table.productname, product_vehicle_table.id as bid from vehicle_table join product_vehicle_table on product_vehicle_table.id=vehicle_table.vehicleproductname where vehicle_table.id=:id";
$query = $dbh -> prepare($sql);
$query-> bindParam(':id', $id, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>


									<div class="panel-body">
<form method="POST"  class="form-horizontal" enctype="multipart/form-data" onSubmit="return valid();">
<div class="form-group">
<label class="col-sm-2 control-label">Vehicle Title<span ></span></label>
<div class="col-sm-4">
<input type="text" name="vehiclename" class="form-control" value="<?php echo htmlentities($result->vehiclename)?>">
</div>
<label class="col-sm-2 control-label">Select Brand<span ></span></label>
<div class="col-sm-4">
<select class="selectpicker" name="vehicleproductname" >
<option value="<?php echo htmlentities($result->bid);?>"><?php echo htmlentities($bdname=$result->productname); ?> </option>
<?php $ret="select id,productname from product_vehicle_table";
$query= $dbh -> prepare($ret);
//$query->bindParam(':id',$id, PDO::PARAM_STR);
$query-> execute();
$resultss = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
foreach($resultss as $results)
{
if($results->productname==$bdname)
{
continue;
} else{
?>
<option value="<?php echo htmlentities($results->id);?>"><?php echo htmlentities($results->productname);?></option>
<?php }}} ?>

</select>
</div>
</div>
											
<div class="form-group">
<label class="col-sm-2 control-label">Price<span ></span></label>
<div class="col-sm-4">
<input type="text" name="vehicleprice" class="form-control" value="<?php echo htmlentities($result->vehicleprice);?>">
</div>
<label class="col-sm-2 control-label">Select Fuel Type<span ></span></label>
<div class="col-sm-4">
<select class="selectpicker" name="vehiclefueltype" >
<option value="<?php echo htmlentities($result->vehiclefueltype);?>"> <?php echo htmlentities($result->vehiclefueltype);?> </option>

<option value="Gasoline">Gasoline</option>
<option value="Diesel Fuel">Diesel Fuel</option>
<option value="Bio Diesel">Bio Diesel</option>
<option value="Ethanol">Ethanol</option>
</select>
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Model Year<span ></span></label>
<div class="col-sm-4">
<input type="text" name="vehicleyear" class="form-control"  value="<?php echo htmlentities($result->vehicleyear);?>">
</div>
<label class="col-sm-2 control-label">Seating Capacity<span ></span></label>
<div class="col-sm-4">
<input type="text" name="vehiclecapacity" class="form-control"  value="<?php echo htmlentities($result->vehiclecapacity);?>">
</div>
</div>
<div class="hr-dashed"></div>


<div class="form-group">
<div class="col-sm-12">
<h4><b>Upload Images</b></h4>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Current Image Upload<span style="color:red"></span></label>
<div class="col-sm-4">
<img src="user/img/<?php echo htmlentities($result->vehicleimage1);?>" width="300" height="200" style="border:solid 1px #000"><img src="user/img/<?php echo htmlentities($result->vehicleimage2);?>" width="300" height="200" style="border:solid 1px #000">
</div>
</div>

<div class="form-group">
<div class="col-sm-4">
Image 1 <span ></span><input type="file" name="vehicleimage1" >
</div>
<div class="col-sm-4">
Image 2<span ></span><input type="file" name="vehicleimage2" >
</div>

</div>


</div>
<div class="hr-dashed"></div>									
</div>
</div>
<?php }} ?>		
											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-4">
								
													<button class="btn btn-primary" name="submit" type="submit">Submit</button>
												</div>
											</div>

											</form>

<h1>HELLO</h1>	 

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

         

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

<?php } ?>