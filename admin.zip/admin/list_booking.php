<?php
session_start();
error_reporting(0);
include('config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{


 ?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

    
<?php
include 'sidebar.php';
?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php
			   include 'header.php';
			   ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Admin</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div>

                
<h1>HELLO</h1>
                    

<div class="panel panel-default">
							<div class="panel-heading">LIST OF BOOKING</div>
							<div class="panel-body">

								<table id="zctb" class="table table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr class="table-primary">
										<th>No</th>
										<th>User Name</th>
											<th>Booking Number</th>
											<th>Vehicle Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Verification Image</th>
											<th>Booking Status</th>
											<th>Booking Timestamp From User</th>
											<th>Action</th>
										</tr>
									</thead>
									<tfoot>
										<tr class="table-primary">
										<th>No</th>
										<th>User Name</th>
											<th>Booking Number</th>
											<th>Vehicle Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Verification Image</th>
											<th>Booking Status</th>
											<th>Booking Timestamp From User</th>
											<th>Action</th>
										</tr>
									</tfoot>
									<tbody>

									<?php 

$status=0;
									//$sql = "SELECT tblusers.FullName,tblbrands.BrandName,tblvehicles.VehiclesTitle,tblbooking.FromDate,tblbooking.ToDate,tblbooking.message,tblbooking.VehicleId as vid,tblbooking.Status,tblbooking.PostingDate,tblbooking.id,tblbooking.BookingNumber  from tblbooking join tblvehicles on tblvehicles.id=tblbooking.VehicleId join tblusers on tblusers.EmailId=tblbooking.userEmail join tblbrands on tblvehicles.VehiclesBrand=tblbrands.id   where tblbooking.Status=:status";
									$sql = "select user_table.username, product_vehicle_table.productname, vehicle_table.vehiclename, booking_table.FromDate, booking_table.ToDate,booking_table.verify_image, booking_table.VehicleId as vid, booking_table.Status, booking_table.bookingdate, booking_table.id, booking_table.BookingNumber from booking_table join vehicle_table on vehicle_table.id=booking_table.VehicleId join user_table on user_table.useremail=booking_table.userEmail join product_vehicle_table on vehicle_table.vehicleproductname=product_vehicle_table.id where booking_table.Status=:status";
$query = $dbh -> prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td><?php echo htmlentities($result->username);?></td>
											<td><?php echo htmlentities($result->BookingNumber);?></td>
											<td><a ><?php echo htmlentities($result->productname);?> , <?php echo htmlentities($result->vehiclename);?></td>
											<td><?php echo htmlentities($result->FromDate);?></td>
											<td><?php echo htmlentities($result->ToDate);?></td>
											<td><img src="user/img/<?php echo htmlentities($result->verify_image);?>" border=2 height=100 width=200  style="float: left;"></img></td>
											<td><?php 
if($result->Status==0)
{
echo htmlentities('Not decide');
} else if ($result->Status==1) {
echo htmlentities('Confirmed');
}
 else{
 	echo htmlentities('Cancelled');
 }
										?></td>
											<td><?php echo htmlentities($result->bookingdate);?></td>
										<td>


<a href="booking_detail.php?bid=<?php echo htmlentities($result->id);?>"> View</a>
</td>

										</tr>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>

						

							</div>
						</div>


<h1>HELLO</h1>	 

<div class="row">
					<div class="col-md-12">


						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-heading">LIST OF BOOKING</div>
							<div class="panel-body">

								<table id="zctb" class="table table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr class="table-success">
										<th>No</th>
											<th>User Name</th>
											<th>Booking Number</th>
											<th>Vehicle Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Verification Image</th>
											<th>Booking Status</th>
											<th>Booking Timestamp From User</th>
											<th>Action</th>
										</tr>
									</thead>
									<tfoot>
										<tr class="table-success">
										<th>No</th>
										<th>User Name</th>
											<th>Booking Number</th>
											<th>Vehicle Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Verification Image</th>
											<th>Booking Status</th>
											<th>Booking Timestamp From User</th>
											<th>Action</th>
										</tr>
									</tfoot>
									<tbody>

									<?php 

$status=1;
									$sql = "select user_table.username, product_vehicle_table.productname, vehicle_table.vehiclename, booking_table.FromDate, booking_table.ToDate,booking_table.verify_image, booking_table.VehicleId as vid, booking_table.Status, booking_table.bookingdate, booking_table.id, booking_table.BookingNumber from booking_table join vehicle_table on vehicle_table.id=booking_table.VehicleId join user_table on user_table.useremail=booking_table.userEmail join product_vehicle_table on vehicle_table.vehicleproductname=product_vehicle_table.id where booking_table.Status=:status";
$query = $dbh -> prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td><?php echo htmlentities($result->username);?></td>
											<td><?php echo htmlentities($result->BookingNumber);?></td>
											<td><a><?php echo htmlentities($result->productname);?> , <?php echo htmlentities($result->vehiclename);?></td>
											<td><?php echo htmlentities($result->FromDate);?></td>
											<td><?php echo htmlentities($result->ToDate);?></td>
											<td><img src="user/img/<?php echo htmlentities($result->verify_image);?>" border=2 height=100 width=200  style="float: left;"></img></td>
											<td><?php 
if($result->Status==0)
{
echo htmlentities('Not decide');
} else if ($result->Status==1) {
echo htmlentities('Confirmed');
}
 else{
 	echo htmlentities('Cancelled');
 }
										?></td>
											<td><?php echo htmlentities($result->bookingdate);?></td>
										<td>


<a href="booking_detail.php?bid=<?php echo htmlentities($result->id);?>"> View</a>
</td>

										</tr>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>

						

							</div>
						</div>

					

					</div>
				</div>
				
				<h1>HELLO</h1>
				
<div class="row">
					<div class="col-md-12">


						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-heading">LIST OF BOOKING</div>
							<div class="panel-body">

								<table id="zctb" class="table table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr class="table-danger">
										<th>No</th>
										<th>User Name</th>
											<th>Booking Number</th>
											<th>Vehicle Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Verification Image</th>
											<th>Booking Status</th>
											<th>Booking Timestamp From User</th>
											<th>Action</th>
										</tr>
									</thead>
									<tfoot>
										<tr class="table-danger">
										<th>No</th>
										<th>User Name</th>
											<th>Booking Number</th>
											<th>Vehicle Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Verification Image</th>
											<th>Booking Status</th>
											<th>Booking Timestamp From User</th>
											<th>Action</th>
										</tr>
									</tfoot>
									<tbody>

									<?php 

$status=2;
									$sql = "select user_table.username, product_vehicle_table.productname, vehicle_table.vehiclename, booking_table.FromDate, booking_table.ToDate,booking_table.verify_image, booking_table.VehicleId as vid, booking_table.Status, booking_table.bookingdate, booking_table.id, booking_table.BookingNumber from booking_table join vehicle_table on vehicle_table.id=booking_table.VehicleId join user_table on user_table.useremail=booking_table.userEmail join product_vehicle_table on vehicle_table.vehicleproductname=product_vehicle_table.id where booking_table.Status=:status";
$query = $dbh -> prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td><?php echo htmlentities($result->username);?></td>
											<td><?php echo htmlentities($result->BookingNumber);?></td>
											<td><a><?php echo htmlentities($result->productname);?> , <?php echo htmlentities($result->vehiclename);?></td>
											<td><?php echo htmlentities($result->FromDate);?></td>
											<td><?php echo htmlentities($result->ToDate);?></td>
											<td><img src="user/img/<?php echo htmlentities($result->verify_image);?>" border=2 height=100 width=200  style="float: left;"></img></td>
											<td><?php 
if($result->Status==0)
{
echo htmlentities('Not decide');
} else if ($result->Status==1) {
echo htmlentities('Confirmed');
}
 else{
 	echo htmlentities('Cancelled');
 }
										?></td>
											<td><?php echo htmlentities($result->bookingdate);?></td>
										<td>


<a href="booking_detail.php?bid=<?php echo htmlentities($result->id);?>"> View</a>
</td>

										</tr>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>

						

							</div>
						</div>

					

					</div>
				</div>

<h1>HELLO				

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

         

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
<?php } ?>