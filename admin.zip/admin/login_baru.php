<?php
session_start();
include('config.php');
if(isset($_POST['loginbaru']))
{
$usernameadmin=$_POST['usernameadmin'];
$passwdadmin=$_POST['passwdadmin'];
$sql ="SELECT * FROM tableadmin WHERE usernameadmin='$usernameadmin' and passwdadmin='$passwdadmin'";
$query= $dbh -> prepare($sql);
if($query->rowCount() > 0)
{

echo "<script type='text/javascript'> document.location = 'dashboard.php'; </script>";
} else{
  
  echo "<script>alert('Invalid Details');</script>";

}

}
?>