<?php
session_start();
error_reporting(0);
include('config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{

if(isset($_REQUEST['eid']))
	{
$eid=intval($_GET['eid']);
$status=2;
$sql = "UPDATE booking_table SET Status=:status WHERE  id=:eid";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query-> bindParam(':eid',$eid, PDO::PARAM_STR);
$query -> execute();
  echo "<script>alert('Booking Successfully Cancelled');</script>";
echo "<script type='text/javascript'> document.location = 'list_booking.php; </script>";
}


if(isset($_REQUEST['aeid']))
	{
$aeid=intval($_GET['aeid']);
$status=1;

$sql = "UPDATE booking_table SET Status=:status WHERE  id=:aeid";
$query = $dbh->prepare($sql);
$query -> bindParam(':status',$status, PDO::PARAM_STR);
$query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
$query -> execute();
echo "<script>alert('Booking Successfully Confirmed');</script>";
echo "<script type='text/javascript'> document.location = 'list_booking.php'; </script>";
}

 ?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

    
<?php
include 'sidebar.php';
?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <?php
			   include 'header.php';
			   ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Admin</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div>

                
<h1>HELLO</h1>
                    

<div class="row">
					<div class="col-md-12">

						<!-- Zero Configuration Table -->
						<div class="panel panel-default">
							<div class="panel-heading">Bookings Info</div>
							<div class="panel-body">


<div id="print">
								<table border="2"  class="table table-bordered table-hover" cellspacing="0" width="100%"  >
				
									<tbody>

									<?php 
$bid=intval($_GET['bid']);
									//$sql = "SELECT tblusers.*,tblbrands.BrandName,tblvehicles.VehiclesTitle,tblbooking.FromDate,tblbooking.ToDate,tblbooking.message,tblbooking.VehicleId as vid,tblbooking.Status,tblbooking.PostingDate,tblbooking.id,tblbooking.BookingNumber,
//DATEDIFF(tblbooking.ToDate,tblbooking.FromDate) as totalnodays,tblvehicles.PricePerDay
	//								  from tblbooking join tblvehicles on tblvehicles.id=tblbooking.VehicleId join tblusers on tblusers.EmailId=tblbooking.userEmail join tblbrands on tblvehicles.VehiclesBrand=tblbrands.id where tblbooking.id=:bid";
									  $sql = "select user_table.*, product_vehicle_table.productname, vehicle_table.vehiclename, booking_table.FromDate, booking_table.ToDate, booking_table.VehicleId as vid, booking_table.Status,booking_table.bookingdate,booking_table.id, booking_table.BookingNumber, DATEDIFF(booking_table.ToDate, booking_table.FromDate) as totaldays, vehicle_table.vehicleprice from booking_table join vehicle_table on vehicle_table.id=booking_table.VehicleId join user_table on user_table.useremail=booking_table.userEmail join product_vehicle_table on vehicle_table.vehicleproductname=product_vehicle_table.id where booking_table.id=:bid";
$query = $dbh -> prepare($sql);
$query -> bindParam(':bid',$bid, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
	<h3 style="text-align:center; color:blue"><?php echo htmlentities($result->BookingNumber);?> Booking Number </h3>

		<tr>
											<th class="table-primary" colspan="4" style="text-align:center;color:black">User Information</th>
										</tr>
										<tr>
											<th style="color:black">Booking Number</th>
											<td><?php echo htmlentities($result->BookingNumber);?></td>
											<th style="color:black">Name</th>
											<td><?php echo htmlentities($result->username);?></td>
										</tr>
										<tr>											
											<th style="color:black">Email Address</th>
											<td><?php echo htmlentities($result->useremail);?></td>
											<th style="color:black">Phone Number</th>
											<td><?php echo htmlentities($result->userphoneno);?></td>
										</tr>
										<tr>
											<th style="color:black">Phone Number</th>
											<td><?php echo htmlentities($result->userphoneno);?></td>
										</tr>
											
										<tr>
											<th class="table-primary" colspan="4" style="text-align:center;color:black">Booking Information</th>
										</tr>
											<tr>											
											<th style="color:black">Vehicle Name</th>
											<td><a href="edit-vehicle.php?id=<?php echo htmlentities($result->vid);?>"><?php echo htmlentities($result->productname);?> , <?php echo htmlentities($result->vehiclename);?></td>
											<th style="color:black">Booking Date</th>
											<td><?php echo htmlentities($result->bookingdate);?></td>
										</tr>
										<tr>
											<th style="color:black">Start Booking Date</th>
											<td><?php echo htmlentities($result->FromDate);?></td>
											<th style="color:black">End Booking Date</th>
											<td><?php echo htmlentities($result->ToDate);?></td>
										</tr>
<tr>
	<th style="color:black">Total Days </th>
	<td><?php echo htmlentities($tdays=$result->totaldays);?></td>
	<th style="color:black">Price/day</th>
	<td><?php echo htmlentities($ppdays=$result->vehicleprice);?></td>
</tr>
<tr>
	<th style="color:black" colspan="3" style="text-align:center"> Total Payment</th>
	<td><a style="color:black"><?php echo htmlentities($tdays*$ppdays);?></td>
</tr>
<tr>
<th style="color:black">Booking Status</th>
<td><?php 
if($result->Status==0)
{
echo htmlentities('Not decide');
} else if ($result->Status==1) {
echo htmlentities('Confirmed');
}
 else{
 	echo htmlentities('Cancelled');
 }
										?></td>
									</tr>

									<?php if($result->Status==0){ ?>
										<tr>	
										<td style="text-align:center" colspan="4">
				<a href="booking_detail.php?aeid=<?php echo htmlentities($result->id);?>" onclick="return confirm('Do you really want to Confirm this booking')" class="btn btn-primary"> Confirm Booking</a> 

<a href="booking_detail.php?eid=<?php echo htmlentities($result->id);?>" onclick="return confirm('Do you really want to Cancel this Booking')" class="btn btn-danger"> Cancel Booking</a>
</td>
</tr>
<?php } ?>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
									
								</table>
								<button onclick="myFunc()"> Print  </button>
		<!-- 						<form method="post">
	   <input name="Submit2" type="submit" class="txtbox4" value="Print" onClick="return f3();" style="cursor: pointer;"  />
	</form>
 -->
							</div>
						</div>

					

					</div>
				</div>

			</div>


	 

<h1>HELLO</h1>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

         

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
	<script>
                   function myFunc() {
					   window.print();
				   }
                </script>

</body>

</html>
<?php } ?>