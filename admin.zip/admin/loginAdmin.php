<?php
session_start();
include('config.php');
if(isset($_POST['login']))
{
$usernameAdmin=$_POST['usernameAdmin'];
$passwdAdmin=md5($_POST['passwdAdmin']);
$sql ="SELECT usernameAdmin,passwdAdmin FROM table_admin WHERE usernameAdmin=:usernameAdmin and passwdAdmin=:passwdAdmin";
$query= $dbh -> prepare($sql);
$query-> bindParam(':usernameAdmin', $usernameAdmin, PDO::PARAM_STR);
$query-> bindParam(':passwdAdmin', $passwdAdmin, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['usernameAdmin'];
echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
} else{
  
  echo "<script>alert('Invalid Details');</script>";

}

}

?>