<?php
$con = mysql_connect("localhost", "root", "P@sscode") or die ("Oops! Server not connected"); // Connect to the host
mysql_select_db("carrental") or die ("Oops! DB not connected"); // select the database
?>